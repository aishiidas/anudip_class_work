package org.anudip.mavenApplication.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
public class DataShow {
	public static void main(String[] args) throws Exception{
		ArrayList<Department> departmentList=new ArrayList<>();
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection connection=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/c5904","root","root");
		String sqlStatement="Select * from department";
		Statement statement=connection.createStatement();
		ResultSet resultSet=statement.executeQuery(sqlStatement);
		while (resultSet.next()) {
			int id=resultSet.getInt(1);
			String name=resultSet.getString(2);
			String location=resultSet.getString(3);
			Department department=new Department(id,name,location);
            departmentList.add(department);
		}//end of loop
		connection.close();
		departmentList.forEach(dept->System.out.println(dept));
	}
}