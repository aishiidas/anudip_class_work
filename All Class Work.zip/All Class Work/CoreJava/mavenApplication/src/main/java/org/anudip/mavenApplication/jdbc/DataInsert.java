package org.anudip.mavenApplication.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;
public class DataInsert {
	public static void main(String[] args) throws Exception{
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter Department Id:");
		int id=Integer.parseInt(scanner.nextLine());
		System.out.println("Enter Department Name:");
		String name=scanner.nextLine();
		System.out.println("Enter Department Location");
		String location=scanner.nextLine();
		DatabaseHandler dbHandler = DatabaseHandler.getDatabaseHandler();
		Connection connection= dbHandler.getConnection();
		String sqlStatement="insert into department values (?,?,?)";
		PreparedStatement statement=connection.prepareStatement(sqlStatement);
		statement.setInt(1, id);
		statement.setString(2, name);
		statement.setString(3, location);
		statement.executeUpdate();
		System.out.println("New Record inserted");
		connection.close();
	}
}