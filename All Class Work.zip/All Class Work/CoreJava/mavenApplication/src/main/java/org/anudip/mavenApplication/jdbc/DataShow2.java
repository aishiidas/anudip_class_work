package org.anudip.mavenApplication.jdbc;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
public class DataShow2 {
	public static void main(String[] args) throws Exception{
		DatabaseHandler dbHandler = DatabaseHandler.getDatabaseHandler();
		Connection connection= dbHandler.getConnection();
		//System.out.println("Hello");
		//Create sql statement
		String sqlStatement="Select * from department";
		//Create link with table to fire query & exchange data
		Statement statement=connection.createStatement();
		//Fire sql query & receive data in a tabular format memory 
		ResultSet resultSet=statement.executeQuery(sqlStatement);
		//extract every row from ResultSet; whether next row/record exists or not
		while (resultSet.next()) {
			int id=resultSet.getInt(1);
			String name=resultSet.getString(2);
			String location=resultSet.getString(3);
			System.out.println(id+" "+name+" "+location);
		}//end of loop
		connection.close();
	}
}