package org.anudip.mavenApplication;

public class Welcome {

	public static void main(String[] args) {
		System.out.println("Hello, Batch ANP-C5904");
		System.out.println("Welcome To Maven");
		
		

	}

}
