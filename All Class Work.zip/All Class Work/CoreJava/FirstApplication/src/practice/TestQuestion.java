package practice;

public class TestQuestion {

public static void main(String args[]) {

int a = 20;

a *= -- a;

System.out.println ("a=" + a);

}

}