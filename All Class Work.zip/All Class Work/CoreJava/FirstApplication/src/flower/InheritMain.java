package flower;

public class InheritMain {

	public static void main(String[] args) {
		Derive2 d = new Derive2();
		//d.show();
		d.display();
	}

}

