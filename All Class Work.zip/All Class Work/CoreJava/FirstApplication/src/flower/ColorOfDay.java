package flower;
import java.util.Scanner;
public class ColorOfDay {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		

	}

}
