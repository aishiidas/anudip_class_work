package org.anudip.string;

public class StringDemo1 {

	public static void main(String[] args) {
		String stg="    XYZPQR    ";
		System.out.println("The length of stg: "+stg.length());
		stg=stg.trim();
		System.out.println("The length of stg: "+stg.length());

	}

}
