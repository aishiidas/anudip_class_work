package org.anudip.string;

public class StringDemo3 {

	public static void main(String[] args) {
		String str="ABCDEFGHIJKLMANOPQRSTUVWXYZ";
//		String sub1=str.substring(5);
//		System.out.println(sub1);
		String sub1=str.substring(5,10);
		System.out.println(sub1);


	}

}
