package org.anudip.thread;

public class LambdaRunnable {

	public static void main(String[] args){
		Runnable r = ()->{
			try {
			for(int i=0;i<5;i++) {
				String name = Thread.currentThread().getName();
				System.out.println("Hello, I am "+name);
				Thread.sleep(2000);
			}//end of loop
			}catch(Exception e) {}
			};//end of lambda
			Thread t1 = new Thread(r,"Asia");
			Thread t2 = new Thread(r,"Europe");
			t1.start();
			t2.start();
			System.out.println("Hi I am main thread");
	}//end of main
}//end of class