package org.anudip.thread;
import java.util.Scanner;

public class Thread1 extends Thread{
	public void run() {
		try {
		Scanner scanner=new Scanner(System.in);
		System.out.println("Enter a Text ");
		String str=scanner.nextLine();
		Thread2 t2=new Thread2(str);
		t2.start();
		synchronized(t2) //t2 will only run now
		{
		
		t2.wait(); //t2 requested all threads to wait until sends a notification that it has completed the task
		}
		String output=t2.show();
		System.out.println("The Reversed Word "+output);
	}catch(Exception e) {}
}
}