package org.anudip.exception;

public class VoterException extends RuntimeException {
	static final long serialVersionUID = 2L;
	 public VoterException(String message) {
	        super(message);
	    }
}
