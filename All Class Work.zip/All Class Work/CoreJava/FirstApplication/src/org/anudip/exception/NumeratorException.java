package org.anudip.exception;

public class NumeratorException extends RuntimeException {
static final long serialVersionUID = 5L;
}
