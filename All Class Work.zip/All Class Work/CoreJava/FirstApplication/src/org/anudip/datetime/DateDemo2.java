package org.anudip.datetime;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;
public class DateDemo2 {
	public static void main(String[] args) throws ParseException {
		Date date=new Date();
		System.out.println(date);
	}
	
}