package org.anudip.interfaceApp;

public class DemoApp {

	public static void main(String[] args) {
		DemoFace df = new DemoFaceImp1();
		df.show();
		df.display();
		//df.putdata();

	}

}
