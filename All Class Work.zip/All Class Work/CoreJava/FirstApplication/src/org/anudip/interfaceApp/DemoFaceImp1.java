package org.anudip.interfaceApp;

public class DemoFaceImp1 implements DemoFace {

	@Override
	public void show() {
		System.out.println("Hi Everybody");

	}

	@Override
	public void display() {
		System.out.println("Hi Everybody");

	}
	public void putdata() {
		System.out.println("Hello Hi");
	}

}
