package org.anudip.service;

public class StudentService {
	public static String calculateGrade(Student2 student) {
	double studentMarks=student.getStudentMarks();
	String studentGrade ="";
	if(studentMarks>=90)
		studentGrade="E";
	else if(studentMarks>=75)
		studentGrade="G";
	else if(studentMarks>=60)
		studentGrade="P";
	else
		studentGrade="F";

return studentGrade;
}
	}


