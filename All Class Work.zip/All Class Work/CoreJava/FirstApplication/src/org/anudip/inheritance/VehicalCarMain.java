package org.anudip.inheritance;
public class VehicalCarMain {

	public static void main(String[] args) {
        Car myCar = new Car();

        myCar.drive();

        myCar.honk();

	}

}
