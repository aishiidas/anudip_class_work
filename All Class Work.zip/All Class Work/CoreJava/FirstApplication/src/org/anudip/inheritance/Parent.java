package org.anudip.inheritance;

public class Parent {
	private int i;
	public Parent() {
		i=10;
		System.out.println("Parent Constructor");
	}
	public void show() {
		System.out.println("The value of i id: "+i);
	}

}
