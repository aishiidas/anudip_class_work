package org.anudip.inheritance;

public class PersonStudentMain {

	public static void main(String[] args) {
		Student st = new Student();
		st.speak();
		st.study();

	}

}
