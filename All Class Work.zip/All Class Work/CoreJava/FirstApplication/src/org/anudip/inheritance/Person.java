package org.anudip.inheritance;

public class Person {
	private String name;
	private int age;
	public Person() {
		name= "Aishi";
		age=21;
	}
	public void speak() {
		System.out.println("The name of the person: "+name+" and age is :"+age);
	}

}
