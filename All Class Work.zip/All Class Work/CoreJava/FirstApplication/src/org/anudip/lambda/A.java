package org.anudip.lambda;

public class A {
public void show() {
	System.out.println("hello");
}
public void putData() {
	System.out.println("Bye");
}
}
