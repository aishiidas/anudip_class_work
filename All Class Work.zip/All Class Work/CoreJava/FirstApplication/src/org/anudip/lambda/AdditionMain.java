package org.anudip.lambda;
import java.util.Scanner;
public class AdditionMain {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		AdditionFace af =(x,y)->{
			return x+y;
		};//end of lambda
		System.out.println("Enter 1st oparand: ");
		int i=Integer.parseInt(scanner.nextLine());
		System.out.println("Enter 2nd oparand: ");
		int j=Integer.parseInt(scanner.nextLine());
		int r =af.add(i, j);
		System.out.println("The Result: "+r);
		scanner.close();

	}

}
