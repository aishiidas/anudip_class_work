package org.anudip.lambda;

@FunctionalInterface
public interface DemoFace {
public String showMessage(String str);
}