package org.anudip.lambda;

public class DImpl implements D {
	//@overeride
	public void show() {
		System.out.println("Hello world");
	}
	//@overeride
	public void disp() {
		System.out.println("Hi world");
	}
	//@overeride
	public void putData() {
		System.out.println("Hello hi");
	}

}
