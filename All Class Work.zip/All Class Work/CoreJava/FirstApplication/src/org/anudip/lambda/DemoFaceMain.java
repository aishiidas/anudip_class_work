package org.anudip.lambda;

public class DemoFaceMain {

	public static void main(String[] args) {
		DemoFace df=(stg)->{
			String str=stg+" is used to impliment functional interface";
					return str;
			};
			String stk="lambda Expression";
			System.out.println(df.showMessage(stk));

	}

}
