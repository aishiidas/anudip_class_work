package org.anudip.FirstSpringApp.config;

import org.anudip.FirstSpringApp.bean.Address;
import org.anudip.FirstSpringApp.bean.Employee;
import org.springframework.context.annotation.Bean;

//It is act as Setter based Dependency Injection
public class EmployeeConfig2 {

	@Bean
	public Address address() {
		Address add=new Address();
		add.setStreet("25,Connought Place");
		add.setCity("New Delhi");
		add.setPin(110025);
		return add;
	}
		
	@Bean
	public Employee employee() {
	Employee ee=new Employee();
	ee.setEmployeeId(10009);
	ee.setEmployeeName("louren Silver");
	ee.setEmployeeAddress(address());
	ee.setEmployeeSalary(56000.00);
	return ee;
	}
}
