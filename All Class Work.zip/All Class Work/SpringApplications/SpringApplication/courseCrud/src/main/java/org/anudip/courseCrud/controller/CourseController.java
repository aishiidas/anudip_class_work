package org.anudip.courseCrud.controller;

import org.anudip.courseCrud.bean.Course;

import org.anudip.courseCrud.dao.CourseDao;
import org.anudip.courseCrud.service.CourseService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;
import java.util.List;


@RestController
public class CourseController {
@Autowired
private CourseDao courseDao;

@Autowired
private CourseService service;

@GetMapping("/index")
public ModelAndView showIndexPage() {
	return new ModelAndView("index");
}


@GetMapping("/course")
public ModelAndView showCourseEntryPage() {
	ModelAndView mv=new ModelAndView("courseEntryPage");
	long newId=courseDao.generateNewCourseId();
	Course course = new Course(newId);
	mv.addObject("courseRecord",course);
	
	return mv;
}
@PostMapping("/course")
public ModelAndView saveUpdateCourse(@ModelAttribute("courseRecord")Course course) {
	Course newCourse=service.gstAndTotalFeeCalculation(course);
	courseDao.saveCourse(newCourse);
	return new ModelAndView("redirect:/index");
}
@GetMapping("/courses")
public ModelAndView showAllCoursesPage() {
	ModelAndView mv=new ModelAndView("courseReportPage");
	List<Course> courseList=courseDao.displayAllCourses();
	mv.addObject("courseReport",courseList);
	return mv;
	
	
}
@GetMapping("/course-find")
	public ModelAndView openCourseFindPage() {
	ModelAndView mv = new ModelAndView("courseFindPage");
	List<Long>courseIdList=courseDao.getAllCourseIds();
	mv.addObject("courseIdList",courseIdList);
	return mv;
}
@PostMapping("/course-find")
public ModelAndView openCourseShowUpdatePage(@RequestParam("course-id") Long courseId,@RequestParam(required=false,value="details") String str, @RequestParam(required=false,value="update") String stg ) {
	String fname="";
	if(stg==null)
		fname="courseShowPage";
	else if(str==null)
		fname="courseUpdatePage";
	ModelAndView mv = new ModelAndView(fname);
	Course course = courseDao.findACourseById(courseId);
	mv.addObject("courseRecord",course);
	return mv;
}

}
