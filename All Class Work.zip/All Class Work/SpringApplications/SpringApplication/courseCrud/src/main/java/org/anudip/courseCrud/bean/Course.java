package org.anudip.courseCrud.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Course {
@Id
private Long courseId;
private String courseName;
private Integer duration;
private Double coursePrice;
private Double gst;
private Double totalFee;
public Course() {
	super();
	// TODO Auto-generated constructor stub
}
public Course(Long courseId, String courseName, Integer duration, Double coursePrice) {
	super();
	this.courseId = courseId;
	this.courseName = courseName;
	this.duration = duration;
	this.coursePrice = coursePrice;
}

public Course(Long courseId) {
	super();
	this.courseId = courseId;
}
public Long getCourseId() {
	return courseId;
}
public void setCourseId(Long courseId) {
	this.courseId = courseId;
}
public String getCourseName() {
	return courseName;
}
public void setCourseName(String courseName) {
	this.courseName = courseName;
}
public Integer getDuration() {
	return duration;
}
public void setDuration(Integer duration) {
	this.duration = duration;
}
public Double getCoursePrice() {
	return coursePrice;
}
public void setCoursePrice(Double coursePrice) {
	this.coursePrice = coursePrice;
}
public Double getGst() {
	return gst;
}
public void setGst(Double gst) {
	this.gst = gst;
}
public Double getTotalFee() {
	return totalFee;
}
public void setTotalFee(Double totalFee) {
	this.totalFee = totalFee;
}

}
