package org.anudip.courseCrud.dao;

import java.util.List;

import org.anudip.courseCrud.bean.Course;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface CourseRepository extends JpaRepository<Course, Long> {
	@Query("select count(courseId) from Course")
	public int getCourseCount();
	
	@Query("select courseId from Course")
	public List<Long> getAllCourseIds();
}