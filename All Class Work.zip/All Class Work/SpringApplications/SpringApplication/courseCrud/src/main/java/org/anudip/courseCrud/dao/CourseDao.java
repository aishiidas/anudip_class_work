package org.anudip.courseCrud.dao;
import java.util.List;


//the methods to declare for database operation
import org.anudip.courseCrud.bean.Course;

public interface CourseDao {
	public void saveCourse(Course course);//store new course
	public List<Course> displayAllCourses();
	public Course findACourseById(Long courseId);
	public Long generateNewCourseId();
	public void deleteCourseById(Long courseId);
	public List<Long> getAllCourseIds();
}
