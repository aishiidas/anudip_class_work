package org.anudip.courseCrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CourseCrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
