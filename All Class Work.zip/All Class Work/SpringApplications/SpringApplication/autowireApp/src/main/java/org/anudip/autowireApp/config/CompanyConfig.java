package org.anudip.autowireApp.config;

import org.anudip.autowireApp.bean.Address;
import org.anudip.autowireApp.bean.Company;
import org.springframework.context.annotation.Bean;

public class CompanyConfig {
	@Bean
	Address address() {
		Address add=new Address();
		add.setStreet("45 Rajaji Road");
		add.setCity("Chennai");
		add.setPin(600032);
		return add;
	}
	@Bean
	Company company(){
		Company comp=new Company();
		comp.setCompanyId(90001);
		comp.setCompanyName("ABC & Company");
		return comp;
	}
}
