package org.anudip.hibernatePropertiesApplication.application;
import java.util.List;
import java.util.Scanner;
import org.anudip.hibernatePropertiesApplication.bean.Country;
import org.anudip.hibernatePropertiesApplication.dao.DatabaseHandler;
import org.hibernate.Query;
import org.hibernate.Session;

public class CountryUpdate {
    public static void main(String[] args) throws Exception {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the country code: ");
        int code = Integer.parseInt(scanner.nextLine());
        // Create a DatabaseHandler instance
        DatabaseHandler dbHandler = DatabaseHandler.getDatabaseHandler();
        // Create a Hibernate session
        Session session = dbHandler.createSession();

        try {
            // Create an HQL query to fetch countries by code
            //String queryStatement = "FROM Country WHERE countryCode = :code";
        	String queryStatement = "FROM Country WHERE countryCode= "+code;
            Query<Country> query = session.createQuery(queryStatement);
            //query.setParameter("code", code);

            // Execute the query and get the list of matching countries
            List<Country> countryList = query.list();
         
         // Print the list of matching countries
         for (Country country : countryList) {
             System.out.println(country);
         }

         // Prompt the user for new GDP and capital values
         System.out.println("Enter new GDP: ");
         double newGdp = Double.parseDouble(scanner.nextLine());
         System.out.println("Enter new capital: ");
         String newCapital = scanner.nextLine();

         // Update GDP and capital in the first matching country
         if (!countryList.isEmpty()) {
             Country countryToUpdate = countryList.get(0);
             countryToUpdate.setGdp(newGdp);
             countryToUpdate.setCapital(newCapital);

             // Save the changes to the database
             session.beginTransaction();
             session.update(countryToUpdate);
             session.getTransaction().commit();
             System.out.println("GDP and capital updated successfully.");
         } else {
             System.out.println("No matching countries found for code " + code);
         }

        } catch (Exception e) {
        } finally {
            session.close();
        }
    }
}